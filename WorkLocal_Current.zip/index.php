<?php header( 'Location: /index.html#home' ) ;  ?>
