<?php header( 'Location: /index.html' ) ;  ?>
